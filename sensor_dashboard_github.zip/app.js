const $=id=>document.getElementById(id);
const n=v=>Number.isFinite(v)?v.toFixed(2):"--";

async function startMagnetometer(){
  if(!("Magnetometer" in window)){
    $("status").textContent="Magnetometer API در این مرورگر در دسترس نیست.";
    return;
  }
  try{
    const m=new Magnetometer({frequency:10});
    m.addEventListener("reading",()=>{
      const x=m.x??0,y=m.y??0,z=m.z??0;
      $("mx").textContent=n(x); $("my").textContent=n(y); $("mz").textContent=n(z);
      $("mt").textContent=n(Math.hypot(x,y,z));
    });
    m.addEventListener("error",e=>{
      $("status").textContent="خطای Magnetometer: "+(e.error?.message||"دسترسی رد شد");
    });
    m.start();
    $("status").textContent="Magnetometer فعال است.";
  }catch(e){
    $("status").textContent="Magnetometer قابل دسترسی نیست: "+e.message;
  }
}

async function startMotion(){
  try{
    if(typeof DeviceMotionEvent!=="undefined" &&
       typeof DeviceMotionEvent.requestPermission==="function"){
      const p=await DeviceMotionEvent.requestPermission();
      if(p!=="granted") throw new Error("اجازه Motion داده نشد");
    }
    window.addEventListener("devicemotion",e=>{
      const a=e.accelerationIncludingGravity||{};
      $("ax").textContent=n(a.x); $("ay").textContent=n(a.y); $("az").textContent=n(a.z);
      const r=e.rotationRate||{};
      $("ga").textContent=n(r.alpha); $("gb").textContent=n(r.beta); $("gg").textContent=n(r.gamma);
    });
  }catch(e){ $("status").textContent=e.message; }
}

$("start").addEventListener("click",async()=>{
  await startMagnetometer();
  await startMotion();
});
