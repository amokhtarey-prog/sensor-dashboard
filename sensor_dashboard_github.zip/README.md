# Phone Sensor Dashboard

A simple GitHub Pages dashboard for browser-accessible phone sensors.

## Files
- index.html
- style.css
- app.js

## GitHub Pages
Repository → Settings → Pages → Deploy from a branch → main → / (root) → Save

Note: browser support for Magnetometer and other hardware sensors varies by device/browser. HTTPS is normally required.
